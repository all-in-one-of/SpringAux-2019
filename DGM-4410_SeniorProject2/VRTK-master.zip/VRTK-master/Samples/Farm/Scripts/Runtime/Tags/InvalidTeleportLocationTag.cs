﻿namespace VRTK.Examples.Tags
{
    using UnityEngine;

    public class InvalidTeleportLocationTag : MonoBehaviour
    {
    }
}
