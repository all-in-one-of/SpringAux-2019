﻿namespace VRTK.Prefabs.Locomotion.BodyRepresentation
{
    using UnityEngine;

    public class BodyRepresentationColliderTag : MonoBehaviour
    {
    }
}